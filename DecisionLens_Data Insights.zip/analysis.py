
import pandas as pd

# Load dataset
df = pd.read_csv("data/business_data.csv")

# Basic data cleaning
df.drop_duplicates(inplace=True)

# Exploratory Data Analysis
print("Dataset Preview:")
print(df.head())

print("\nSummary Statistics:")
print(df.describe())

print("\nSales by Region:")
print(df.groupby("region")["sales"].sum())
