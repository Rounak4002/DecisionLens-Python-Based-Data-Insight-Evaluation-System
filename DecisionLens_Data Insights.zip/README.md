
# DecisionLens – Python-Based Data Insight & Evaluation System

## Overview
DecisionLens is a beginner-friendly data analysis project focused on cleaning, exploring, and analyzing structured datasets using Python and SQL concepts.

## Tech Stack
- Python
- Pandas
- SQL (query logic)
- Exploratory Data Analysis (EDA)

## Project Structure
- data/ → sample dataset
- analysis.py → data cleaning & EDA
- queries.sql → sample SQL queries
- README.md

## Key Tasks Performed
- Data cleaning and preprocessing
- Exploratory data analysis (EDA)
- Basic SQL queries for reporting

## Usage
Run the analysis script:
```bash
python analysis.py
```
